import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

class SongCollection {
    private Song[] theSongs;
    public SongCollection() { theSongs = new Song[0]; }
    public int size() { return theSongs.length; }



    public void writeToFile(File f) {
        try {
            PrintStream write = new PrintStream(f);
            write.println(size());
            for (int i = 0; i < size(); i++){
                write.println(theSongs[i].getTitle());
                write.println(theSongs[i].getArtist());

            }
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFound");
        }
    }

    public void addFromFile( File f ){
        try {
            Scanner keyboard;
            keyboard = new Scanner(f);
            int numsongs = Integer.parseInt(keyboard.nextLine());

            Song[] merged = Arrays.copyOf( theSongs, theSongs.length + numsongs);
            for (int i=theSongs.length; i<theSongs.length + numsongs; i++){
                String tempt = keyboard.nextLine();
                String tempa = keyboard.nextLine();
                Song temps = new Song(tempt, tempa);
                merged [i] = temps;
            }
            theSongs = merged;
        }
        catch(FileNotFoundException e){
            System.out.println("Error!");
        }
    }

    public void addOneSong( String t, String a ){
        try {

            Song[] merged = Arrays.copyOf(theSongs, theSongs.length -1);
            Song temps = new Song(t, a);
            merged [merged.length-1] = temps;
            theSongs = merged;
        }
        catch(Exception e){
            System.out.print("***File Not Found***");
        }
    }

    public void searchByTitle( String key ){
        for (int i = 0; i< theSongs.length; i++){
            String temp = theSongs[i].getTitle();
            if (temp.indexOf(key)>-1){
                System.out.println((i)+": " + theSongs[i].getTitle()+" , " + theSongs[i].getArtist());
            }
        }
    }
    public void searchByArtist( String key ){
        for (int i = 0; i< theSongs.length; i++){
            String temp = theSongs[i].getArtist();
            if (temp.indexOf(key)>-1) {
                System.out.println((i) + ": " + theSongs[i].getTitle() + " , " + theSongs[i].getArtist());
            }
        }
    }
    public void show( int start, int end ){
        for (int i= start; i<end; i++){
            System.out.println((i) + ": " + theSongs[i].getTitle() + " , " + theSongs[i].getArtist());
        }
    }
    public void delete( int pos){
        int lengthOf = theSongs.length;
        Song[] merged = Arrays.copyOf(theSongs, theSongs.length -1);
        for (int i = 0, j = 0; i< theSongs.length; i++) {
            if (i != pos) {
                merged[j++] = theSongs[i];
            }
        }
        theSongs = merged;
    }

}

