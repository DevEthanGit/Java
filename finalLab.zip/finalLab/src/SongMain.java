import java.util.*;
import java.io.File;

public class SongMain {
    public static void main (String [] args){
        Scanner keyboard = new Scanner(System.in);
        SongCollection mSong = new SongCollection();
        int choice = 1;
        while(choice != 0 ) {
            System.out.println("========Select action========\n" +
                    "0. Quit\n" +
                    "1. Get collection size\n" +
                    "2. Search for title\n" +
                    "3. Search for artist\n" +
                    "4. Add from file\n" +
                    "5. Save to file\n" +
                    "6. Add one song\n" +
                    "7. Remove one song\n" +
                    "8. Show\n" +
                    "Enter choice:  ");
            choice = keyboard.nextInt();
            String key = "";
            switch( choice ) {
                case 0:
                    System.out.println("Bye!");
                    break;

                case 1:
                    System.out.println("Size = " + mSong.size());
                    break;

                case 2:
                    keyboard.nextLine();
                    System.out.println("Enter a Title");
                    key=keyboard.nextLine();
                    mSong.searchByTitle(key);
                    break;

                case 3:
                    keyboard.nextLine();
                    System.out.println("Enter an Artist");
                    key=keyboard.nextLine();
                    mSong.searchByArtist(key);
                    break;

                case 4:
                    keyboard.nextLine();
                    System.out.println("Enter File Name");
                    String filename = keyboard.nextLine();
                    File f = new File(filename);
                    mSong.addFromFile(f);
                    break;

                case 5:
                    keyboard.nextLine();
                    System.out.println("Enter File Name: ");
                    String filename1 = keyboard.nextLine();
                    File f1 = new File(filename1);
                    mSong.writeToFile(f1);
                    break;

                case 6:
                    keyboard.nextLine();
                    System.out.println("Enter Title:");
                    String t=keyboard.nextLine();
                    System.out.println("Enter Artist:");
                    String a=keyboard.nextLine();
                    mSong.addOneSong(t,a);
                    break;

                case 7:
                    int pos;
                    System.out.println("Enter Position:");
                    pos=keyboard.nextInt();
                    mSong.delete(pos);
                    break;

                case 8:
                    int start, end;
                    System.out.println("enter start: ");
                    start = keyboard.nextInt();
                    System.out.println("enter end: ");
                    end = keyboard.nextInt();
                    mSong.show(start, end);
                    break;
                default: System.out.println("Please type a number 0-8! ");

            }
        }
    }
}
