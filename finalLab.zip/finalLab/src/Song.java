public class Song implements Comparable<Song> {
    String title = "", artist = "";
    Song(String t, String a){
        title = t;
        artist = a;
    }
    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    @Override
    public int compareTo(Song o) {
        return 0;
    }
}
